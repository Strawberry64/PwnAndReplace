
Project Name: Pwn and Replace
Team Members: Luis Medina, Alexangelo Orozco Gutierrez, Landon Wivell, Miracle Marasigan
Class: CST 205
Date: May 14 2024

How to Run the Program:
1. Clone the repository to your local machine via your terminal: git clone https://github.com/Strawberry64/PwnAndReplace.git
2. Navigate to the project directory: cd PwnAndReplace
3. If terminal errors indicate missing requirements, simply get your hands on those missing ones.
4. Run the Flask application via your terminal: py main.py (Windows) or python main.py (Mac)
5. Access the application in your web browser at http://127.0.0.1:5000/

GitHub Repository: https://github.com/Strawberry64/PwnAndReplace

Future Work:
Possible UI updates
Possible updates on information page